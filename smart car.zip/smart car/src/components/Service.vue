<template>
    <div class="service">
        <h2>客服反馈</h2>
      </div>
</template>

<script lang="ts" name="Service">
export default{
    name:'service',
}
</script>




<style scoped>
.service{
  display: flex;
  justify-content: center;
  height: 100%;
  color: wheat;
  font-size: 18px;
  text-align: center;
}
</style>