<template>
    <div class="parking">
        <h2>泊车点查询</h2>
      </div>
</template>

<script lang="ts" name="parking">
export default{
    name:'parking',
}
</script>




<style scoped>
.parking{
  display: flex;
  justify-content: center;
  height: 100%;
  color: wheat;
  font-size: 18px;
  text-align: center;
}
</style>