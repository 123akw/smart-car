<template>
    <div class="news">
        <h2>新闻资讯</h2>
      </div>
</template>

<script lang="ts" name="news">
export default{
    name:'news',
}
</script>




<style scoped>
.news{
  height: 100%;
  color: wheat;
  font-size: 18px;
  text-align: center;
}
</style>