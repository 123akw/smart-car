<template>
    <div class="payment">
        <h2>自助缴费</h2>
      </div>
</template>

<script lang="ts" name="payment">
export default{
    name:'payment',
}
</script>




<style scoped>
.payment{
  display: flex;
  justify-content: center;
  height: 100%;
  color: wheat;
  font-size: 18px;
  text-align: center;
}
</style>