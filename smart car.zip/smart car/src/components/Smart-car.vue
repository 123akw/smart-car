<template>
    <div class="smart-car">
        <h2>智能泊车系统</h2>
      </div>
</template>

<script lang="ts" name="Smart-car">
export default{
    name:'smart-car',
}
</script>




<style scoped>
.smart-car{
  display: flex;
  justify-content: center;
  height: 100%;
  color: wheat;
  font-size: 18px;
  text-align: center;
}
</style>